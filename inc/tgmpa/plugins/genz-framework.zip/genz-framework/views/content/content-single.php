<article <?php post_class() ?>>
    <?php genz_framework_template('single/event-info'); ?>
</article>