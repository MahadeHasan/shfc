<?php
extract(wp_parse_args($args, [
    'title'              => '',
    'description'       => '',

]));

?>

<div class="mb-50 section-title">
    <h2 class="color-linear d-inline-block mb-10 wow animate__animated animate__fadeInUp"><?php echo esc_html($title); ?></h2>
    <?php if (!empty($description)) : ?>
        <p class="text-lg mb-0 color-gray-500 wow animate__animated animate__fadeInUp"><?php echo esc_html($description); ?></p>
    <?php endif; ?>
</div>