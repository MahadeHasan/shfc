<?php
extract(wp_parse_args($args, [
	'tags_alignment' => '',
]));


get_template_part('template-parts/common/popular-tags');
