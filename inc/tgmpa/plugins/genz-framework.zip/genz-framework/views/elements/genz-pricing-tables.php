<?php
extract(wp_parse_args($args, [
    'pricing_tables' => [],
]));

?>

<?php if (!empty($pricing_tables)) : ?>
    <div class="row mb-30">
        <?php
        $count = 1;
        foreach ($pricing_tables as $pricing_table) :
            $pricing_table = wp_parse_args($pricing_table, [
                'package_name' => '',
                'plan_badge_enable' => '',
                'plan_badge_name' => '',
                'badge_color' => '',
                'sub_title' => '',
                'description' => '',
                'try_btn' => '',
                'try_btn_link' => '',
                'learn_more_btn' => '',
                'learn_more_link' => '',
                'features' => [],
            ]);

        ?>
            <div class="col-lg-4 wow animate__animated animate__fadeIn" data-wow-delay=".0s">
                <div class="card-pricing border-gray-800 bg-gray-850 mb-30">
                    <?php if ($pricing_table['plan_badge_enable'] == 'yes') : ?>
                        <label class="<?php echo esc_attr($pricing_table['badge_color']) ?> badge text-base color-gray-900">
                            <?php echo esc_attr($pricing_table['plan_badge_name'])  ?>
                        </label>
                    <?php endif; ?>
                    <div class="card-pricing-top border-gray-800">
                        <h3 class="color-white"><?php echo esc_attr($pricing_table['package_name'])  ?></h3>
                        <p class="text-lg color-gray-500 mb-15"><?php echo esc_attr($pricing_table['sub_title'])  ?></p>
                        <p class="text-sm color-gray-500 mb-30"><?php echo esc_attr($pricing_table['description'])  ?></p>
                        <a href="<?php echo esc_attr($pricing_table['try_btn_link'])  ?>" class="btn btn-border-linear">
                            <?php echo esc_attr($pricing_table['try_btn'])  ?>
                        </a>
                        <a href="<?php echo esc_attr($pricing_table['learn_more_link'])  ?>" class="btn btn-link-more">
                            <?php echo esc_attr($pricing_table['learn_more_btn'])  ?>
                        </a>
                    </div>
                    <!-- card-pricing-top -->
                    <?php if (empty($pricing_table['features'])) continue; ?>
                    <div class="card-pricing-bottom">
                        <h6 class="color-white mb-25"><?php esc_attr_e('What you get:', 'genz') ?></h6>
                        <ul class="list-checked">
                            <?php foreach ($pricing_table['features'] as $feature) : ?>
                                <li><?php echo esc_attr($feature['feature_item']) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <!-- card-pricing-bottom -->
                </div>
                <!-- card-pricing -->
            </div>
            <!-- col-lg-4 -->
        <?php endforeach; ?>
    </div>
    <!-- row -->
<?php endif; ?>