<?php
extract(wp_parse_args($args, [
    'author_image'          => '',
    'welcome_text'          => '',
    'author_quote'          => '',
    'social_links'          => '',

]));

$alt_text = get_bloginfo('name');

?>
<div class="banner banner-home4 bg-gray-850">
    <div class="container">
        <div class="row align-items-start">
            <div class="col-xl-1"></div>
            <div class="col-xl-10 col-lg-12">
                <div class="pt-20">
                    <div class="box-banner-4">
                        <div class="banner-image">
                            <img src="<?php echo esc_attr($author_image['url']); ?>" alt="<?php echo esc_attr($alt_text); ?>">
                        </div>
                        <div class="banner-info">
                            <span class="text-sm-bold d-block color-gray-600"><?php echo esc_attr($welcome_text) ?></span>
                            <h3 class="color-linear d-block mt-10 mb-15"><?php echo esc_attr($author_quote) ?></h3>
                            <?php if (!empty($social_links)) :  ?>
                                <div class="box-socials">
                                    <?php foreach ($social_links as $social_link) :  ?>
                                        <a class="bg-gray-800 hover-up" href="<?php echo esc_url($social_link['social_link']) ?>">
                                            <?php echo genz_get_social_link_svg($social_link['social_link'], 18); ?>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                                <!-- box-socials -->
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>