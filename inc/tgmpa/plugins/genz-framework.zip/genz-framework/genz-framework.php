<?php
/*
Plugin Name: Genz Framework
Plugin URI: https://senseflame.com/
Description: The  Genz Framework Website Builder has it all: drag and drop page builder, mobile responsive editing, and more.
Author: themeperch
Version: 1.0.2
Author URI: https://codecanyon.net/themeperch/
*/

// Exit if accessed directly.
defined('ABSPATH') || die;

if (!function_exists('genz_module_load')) {
	add_action('init', 'genz_module_load', 1);

	function genz_module_load()
	{

		require __DIR__ . '/vendor/autoload.php';

		define('ELEMENTOR_GENZ_URI', trailingslashit(plugin_dir_url(__FILE__)));
		define('ELEMENTOR_GENZ_VER', '1.0.2');
		define('ELEMENTOR_GENZ_ASSETS', trailingslashit(ELEMENTOR_GENZ_URI . 'assets'));
		define('ELEMENTOR_GENZ_DIR', trailingslashit(plugin_dir_path(__FILE__)));
		define('ELEMENTOR_GENZ_TEMPLATEPATH', trailingslashit(plugin_dir_path(__FILE__) . 'views'));


		new ControlEvents\Loader;
	}
}
