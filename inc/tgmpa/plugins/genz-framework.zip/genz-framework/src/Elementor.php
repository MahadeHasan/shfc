<?php

namespace ControlEvents;

class Elementor
{
    /**
     * Add hooks when module is loaded.
     */
    public function __construct()
    {
        add_action('elementor/widgets/register', [$this, 'register_widget']);
        add_action('elementor/elements/categories_registered', [$this, 'add_widget_categories']);
    }

    public function register_widget($widgets_manager)
    {
        $widgets_manager->register(new Widgets\Genz_Section_Title());
        $widgets_manager->register(new Widgets\About_Us());
        $widgets_manager->register(new Widgets\Genz_Testimonials());
        $widgets_manager->register(new Widgets\Genz_Brand());
        $widgets_manager->register(new Widgets\Genz_Pricing_Tables());
        $widgets_manager->register(new Widgets\Genz_Faqs());
        $widgets_manager->register(new Widgets\Genz_Services());
        $widgets_manager->register(new Widgets\Genz_Portfolio());
        $widgets_manager->register(new Widgets\Genz_Category());
        $widgets_manager->register(new Widgets\Genz_Post_Tags());
        $widgets_manager->register(new Widgets\Genz_Banner_Tags());
        $widgets_manager->register(new Widgets\Genz_Banner_Category());
        $widgets_manager->register(new Widgets\Genz_Posts());
        $widgets_manager->register(new Widgets\Genz_Author_Banner());
        $widgets_manager->register(new Widgets\Genz_Contact_Info());
    }

    public function add_widget_categories($elements_manager)
    {

        $elements_manager->add_category(
            'elementor-genz',
            [
                'title' => esc_html__('Genz Widgets', 'elementor-genz'),
                'icon' => 'fa fa-plug',
            ]
        );
    }
}
