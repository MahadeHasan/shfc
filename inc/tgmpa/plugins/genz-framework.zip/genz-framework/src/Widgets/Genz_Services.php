<?php

namespace ControlEvents\Widgets;

class Genz_Services extends \Elementor\Widget_Base
{
	public function get_name()
	{
		return 'genz_services';
	}

	public function get_title()
	{
		return esc_html__('Services', 'elementor-genz');
	}

	public function get_icon()
	{
		return 'eicon-price-list';
	}

	public function get_categories()
	{
		return ['elementor-genz'];
	}

	public function get_keywords()
	{
		return ['services', 'genz'];
	}

	protected function register_controls()
	{

		// Funfact Tab Start
		$this->start_controls_section(
			'service_information',
			[
				'label' => esc_html__('Services List', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'icon',
			[
				'label' => esc_html__('Icon', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'service_title',
			[
				'label' => esc_html__('Services Title', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'services_desc',
			[
				'label' => esc_html__('Services Content', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);

		$this->add_control(
			'services_listtt',
			[
				'label' => esc_html__('Services List', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default'	=> 	$this->services_defaults_item(),
				'label_block' => true,
			]
		);

		$this->end_controls_section();
		// end_controls_section 

	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();
		genz_framework_template('elements/genz-services', '', $settings);
	}

	protected function services_defaults_item()
	{
		return array(
			[
				'icon'				=> [
					'value'			=> 'icon-motion',
				],
				'service_title'		=> 'Motion & Web Graphy', 'elementor-genz',
				'services_desc'		=> 'NetTracking" is a very powerful Web 2.0 site search engine allows you to find email allerts', 'elementor-genz'
			],
			[
				'icon'				=> [
					'value'			=> 'icon-ui',
				],
				'service_title'		=> 'UI/Ux Consultancy', 'elementor-genz',
				'services_desc'		=> 'NetTracking" is a very powerful Web 2.0 site search engine allows you to find email allerts', 'elementor-genz'
			],
			[
				'icon'				=> [
					'value'			=> 'icon-branding',
				],
				'service_title'		=> 'Branding & Design', 'elementor-genz',
				'services_desc'		=> 'NetTracking" is a very powerful Web 2.0 site search engine allows you to find email allerts', 'elementor-genz'
			],
			[
				'icon'				=> [
					'value'			=> 'icon-product',
				],
				'service_title'		=> 'Product Photography', 'elementor-genz',
				'services_desc'		=> 'NetTracking" is a very powerful Web 2.0 site search engine allows you to find email allerts', 'elementor-genz'
			],
			[
				'icon'				=> [
					'value'			=> 'icon-key',
				],
				'service_title'		=> 'Key Seo Optimization', 'elementor-genz',
				'services_desc'		=> 'NetTracking" is a very powerful Web 2.0 site search engine allows you to find email allerts', 'elementor-genz'
			],
			[
				'icon'				=> [
					'value'			=> 'icon-social',
				],
				'service_title'		=> 'Social Management', 'elementor-genz',
				'services_desc'		=> 'NetTracking" is a very powerful Web 2.0 site search engine allows you to find email allerts', 'elementor-genz'
			],
		);
	}
}
