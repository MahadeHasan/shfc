<?php

namespace ControlEvents\Widgets;

class Genz_Banner_Tags extends \Elementor\Widget_Base
{
	public function get_name()
	{
		return 'genz_banner_tags';
	}

	public function get_title()
	{
		return esc_html__('Banner With Tags', 'elementor-genz');
	}

	public function get_icon()
	{
		return 'eicon-tags';
	}

	public function get_categories()
	{
		return ['elementor-genz'];
	}

	public function get_keywords()
	{
		return ['tags'];
	}

	protected function register_controls()
	{

		// About Features Tab Start  
		$this->start_controls_section(
			'banner_tags_tab',
			[
				'label' => esc_html__('Banner With Tags', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label' => esc_html__('Sub Title', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_attr__('Welcome to our blog', 'elementor-genz'),
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__('Title', 'elementor-genz'),
				'description'	=> esc_html__('Use { your text } to mark highlight text', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'default' => esc_attr__('Being Unique is better	than being Effect', 'elementor-genz'),

			]
		);
		$this->add_control(
			'number_of_tag',
			[
				'label' => esc_html__('Number of Tags', 'elementor-genz'),
				'description'	=> esc_html__('Enter your number, how many tags you wanna show', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 10,

			]
		);
		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();
		genz_framework_template('elements/genz-banner-tags', '', $settings);
	}
}
