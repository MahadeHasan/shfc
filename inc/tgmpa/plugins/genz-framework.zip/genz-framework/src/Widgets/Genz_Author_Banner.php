<?php

namespace ControlEvents\Widgets;

class Genz_Author_Banner extends \Elementor\Widget_Base
{
	public function get_name()
	{
		return 'genz_author_banner';
	}

	public function get_title()
	{
		return esc_html__('Genz Author Banner', 'elementor-genz');
	}

	public function get_icon()
	{
		return 'eicon-user-circle-o';
	}

	public function get_categories()
	{
		return ['elementor-genz'];
	}

	public function get_keywords()
	{
		return ['author', 'control', 'genz'];
	}

	protected function register_controls()
	{

		// Content Tab Start 
		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__('Author Banner Content', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'author_image',
			[
				'label' => esc_html__('Author Image', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
				'default' => [
					'url' => get_theme_file_uri('assets/imgs/page/homepage4/banner.png'),
				],
			]
		);
		$this->add_control(
			'welcome_text',
			[
				'label' => esc_html__('Welcome Text', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__('Hello Everyone!', 'elementor-genz')
			]
		);
		$this->add_control(
			'author_quote',
			[
				'label' => esc_html__('Authore Quote', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'default' => esc_html__('I\'m Steven, a lover of technology, business and experiencing new things', 'elementor-genz')
			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'social_title',
			[
				'label' => esc_html__('Social Media Title', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'social_link',
			[
				'label' => esc_html__('Social Media Link', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'social_links',
			[
				'label' => esc_html__('Brands', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'social_title' 	=> esc_html__('Facebook', 'elementor-genz'),
						'social_link' 	=> esc_url('https://www.facebook.com/#')
					],
					[
						'social_title' 	=> esc_html__('Instagram', 'elementor-genz'),
						'social_link' 	=> esc_url('https://www.instagram.com/#')
					],
					[
						'social_title' 	=> esc_html__('Snapchat', 'elementor-genz'),
						'social_link' 	=> esc_url('https://www.snapchat.com/#')
					],
					[
						'social_title' 	=> esc_html__('Twitter', 'elementor-genz'),
						'social_link' 	=> esc_url('https://www.twitter.com/#')
					]
				],
				'title_field' => '{{{ social_title }}}',
			]
		);

		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();
		genz_framework_template('elements/genz-author-banner', '', $settings);
	}
}
