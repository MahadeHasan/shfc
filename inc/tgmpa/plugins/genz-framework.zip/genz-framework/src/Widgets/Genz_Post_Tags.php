<?php

namespace ControlEvents\Widgets;

class Genz_Post_Tags extends \Elementor\Widget_Base
{
	public function get_name()
	{
		return 'genz_post_tags';
	}

	public function get_title()
	{
		return esc_html__('Genz Tags', 'elementor-genz');
	}

	public function get_icon()
	{
		return 'eicon-tags';
	}

	public function get_categories()
	{
		return ['elementor-genz'];
	}

	public function get_keywords()
	{
		return ['tags'];
	}

	protected function register_controls()
	{

		// About Features Tab Start  
		$this->start_controls_section(
			'post_tags_tab',
			[
				'label' => esc_html__('Popular Tags', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'tags_alignment',
			[
				'label' => esc_html__('Alignment', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__('Left', 'elementor-genz'),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', 'elementor-genz'),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__('Right', 'elementor-genz'),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .section-title' => 'text-align: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();
		genz_framework_template('elements/genz-post-tags', '', $settings);
	}
}
