<?php

namespace ControlEvents\Widgets;

class Genz_Section_Title extends \Elementor\Widget_Base
{
	public function get_name()
	{
		return 'section_title';
	}

	public function get_title()
	{
		return esc_html__('Section Title', 'elementor-genz');
	}

	public function get_icon()
	{
		return 'eicon-site-title';
	}

	public function get_categories()
	{
		return ['elementor-genz'];
	}

	public function get_keywords()
	{
		return ['section title', 'genz'];
	}

	protected function register_controls()
	{

		// Content Tab Start
		$this->start_controls_section(
			'section_title',
			[
				'label' => esc_html__('Section Title', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__('Title', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__('Section Title', 'elementor-genz'),
			]
		);
		$this->add_control(
			'description',
			[
				'label' => esc_html__('Description', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'default' => esc_html__('Lorem ipsum, dolor sit amet consectetur adipisicing elit.', 'elementor-genz'),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_title_alignment',
			[
				'label' => esc_html__('Style', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'text_align',
			[
				'label' => esc_html__('Alignment', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__('Left', 'elementor-genz'),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__('Center', 'elementor-genz'),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__('Right', 'elementor-genz'),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .section-title' => 'text-align: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();
	}



	protected function render()
	{
		$settings = $this->get_settings_for_display();
		genz_framework_template('elements/genz-section-title', '', $settings);
	}
}
