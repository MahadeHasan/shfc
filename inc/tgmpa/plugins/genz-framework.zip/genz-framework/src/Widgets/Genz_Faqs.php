<?php

namespace ControlEvents\Widgets;

class Genz_Faqs extends \Elementor\Widget_Base
{
	public function get_name()
	{
		return 'genz_faq';
	}

	public function get_title()
	{
		return esc_html__('Genz FaQ', 'elementor-genz');
	}

	public function get_icon()
	{
		return 'eicon-help';
	}

	public function get_categories()
	{
		return ['elementor-genz'];
	}

	public function get_keywords()
	{
		return ['faq', 'event'];
	}

	protected function register_controls()
	{


		//Faq Tab Start  
		$this->start_controls_section(
			'genz_faq_tab',
			[
				'label' => esc_html__('Faq Item Content', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'question',
			[
				'label' => esc_html__('Question', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => 'Over 20 Years of Experience',
			]
		);
		$repeater->add_control(
			'answer',
			[
				'label' => esc_html__('Answer', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'Over 20 Years of Experience Over 20 Years of Experience',
			]
		);


		$this->add_control(
			'faqs',
			[
				'label' => esc_html__('FAQs', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ question }}}',
				'default' => [
					[
						'question' => esc_html__('Understanding company billing and accounts', 'elementor-genz'),
						'answer' => esc_html__('Nulla non sollicitudin. Morbi sit amet laoreet ipsum, vel pretium mi.
						Morbi varius, tellus in accumsan blandit, elit ligula eleifend velit, luctus mattis ante nulla
						condimentum nulla.', 'elementor-genz'),
					],
					[
						'question' => esc_html__('Updating your billing credit card', 'elementor-genz'),
						'answer' => esc_html__('Nulla non sollicitudin. Morbi sit amet laoreet ipsum, vel pretium mi.
						Morbi varius, tellus in accumsan blandit, elit ligula eleifend velit, luctus mattis ante nulla
						condimentum nulla.', 'elementor-genz'),
					],
					[
						'question' => esc_html__('Application keyboard shortcuts and tips', 'elementor-genz'),
						'answer' => esc_html__('Nulla non sollicitudin. Morbi sit amet laoreet ipsum, vel pretium mi.
						Morbi varius, tellus in accumsan blandit, elit ligula eleifend velit, luctus mattis ante nulla
						condimentum nulla.', 'elementor-genz'),
					],
					[
						'question' => esc_html__('Cancelling a website subscription', 'elementor-genz'),
						'answer' => esc_html__('Nulla non sollicitudin. Morbi sit amet laoreet ipsum, vel pretium mi.
						Morbi varius, tellus in accumsan blandit, elit ligula eleifend velit, luctus mattis ante nulla
						condimentum nulla.', 'elementor-genz'),
					]
				],

			]
		);


		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();
		genz_framework_template('elements/genz-faqs', '', $settings);
	}
}
