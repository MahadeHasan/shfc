<?php

namespace ControlEvents\Widgets;

trait Helper
{

	protected function wp_query($instance = null, $args = [])
	{
		if (empty($instance)) {
			$instance = $this;
		}

		$args = wp_parse_args($args, [
			'prefix' => '',
			'label' => esc_html__('WP Query', 'elementor-genz'),
			'posts_per_page' => 3,
			'post_type' => 'post',
			'data' => '',
			'extra_class' => '',
		]);

		$instance->start_controls_section(
			$args['prefix'] . 'wp_query_tab',
			[
				'label' => $args['label'],
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$instance->add_control(
			$args['prefix'] . 'post_type',
			[
				'label' => esc_html__('Post type', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'post' => 'Post'
				],
				'default' => $args['post_type']
			]
		);

		$instance->add_control(
			$args['prefix'] . 'posts_per_page',
			[
				'label' => esc_html__('Posts per page', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => '-1',
				'step' => '1',
				'max' => '50',
				'default' => $args['posts_per_page']
			]
		);

		$instance->end_controls_section();
	}


	protected function button_controls($instance = null, $args = [])
	{
		if (empty($instance)) {
			$instance = $this;
		}
		$args = wp_parse_args($args, [
			'prefix' => 'button_',
			'text' => esc_html__('Resister Now', 'elementor-genz'),
			'url' => '#',
			'style' => '',
			'data' => '',
			'extra_class' => '',
		]);

		$instance->add_control(
			$args['prefix'] . 'text',
			[
				'label' => esc_html__('Button text', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => $args['text'],
				'label_block' => true
			]
		);
		$instance->add_control(
			$args['prefix'] . 'url',
			[
				'label' => esc_html__('Button URL', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => $args['url'],
				'placeholder' => 'https://',
				'label_block' => true
			]
		);
		$instance->add_control(
			$args['prefix'] . 'video',
			[
				'label' => esc_html__('Enable video popup', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
			]
		);
		$instance->add_control(
			$args['prefix'] . 'style',
			[
				'label' => esc_html__('Style', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'btn-link',
				'options' => $this->button_style_class_options(),
			]
		);

		$instance->add_control(
			$args['prefix'] . 'extra_class',
			[
				'label' => esc_html__('CSS Classes', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => $args['extra_class'],
				'label_block' => true
			]
		);
		$instance->add_control(
			$args['prefix'] . 'data',
			[
				'label' => esc_html__('Data Attributes', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true
			]
		);
	}


	protected function render_button($args = [])
	{
		genz_framework_template('elements/button', '', $args);
	}

	protected function button_style_class_options()
	{

		$options = [
			'btn-link' => esc_html__('Link', 'elementor-genz'),
			'btn-primary' => esc_html__('Primary', 'elementor-genz'),
			'btn-outline-primary' => esc_html__('Primary Outline', 'elementor-genz'),
			'btn-secondary' => esc_html__('Secondary', 'elementor-genz'),
			'btn-outline-secondary' => esc_html__('Secondary outline', 'elementor-genz'),
			'btn-info' => esc_html__('Info', 'elementor-genz'),
			'btn-success' => esc_html__('Success', 'elementor-genz'),
			'btn-warning' => esc_html__('Warning', 'elementor-genz'),
			'btn-danger' => esc_html__('Danger', 'elementor-genz'),
			'custom-btn2' => esc_html__('Theme style', 'elementor-genz'),
			'custom-btn item-btn' => esc_html__('Theme style 2', 'elementor-genz'),
		];
		return apply_filters('control_events_button_style_class_options', $options);
	}
}
