<?php

namespace ControlEvents\Widgets;

class Genz_Pricing_Tables extends \Elementor\Widget_Base
{
	public function get_name()
	{
		return 'genz_pricing_tables';
	}

	public function get_title()
	{
		return esc_html__('Genz Pricing tables', 'elementor-genz');
	}

	public function get_icon()
	{
		return 'eicon-price-table';
	}

	public function get_categories()
	{
		return ['elementor-genz'];
	}

	public function get_keywords()
	{
		return ['pricing', 'control', 'event'];
	}

	protected function register_controls()
	{

		// Content Tab Start

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__('Pricing Table', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'package_name',
			[
				'label' => esc_html__('Package Name', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('Free', 'genz'),
				'label_block' => true
			]
		);
		$repeater->add_control(
			'plan_badge_enable',
			[
				'label' => esc_html__('Plan Badge ', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes'
			]
		);
		$repeater->add_control(
			'badge_color',
			[
				'label' => esc_html__('Select Color Badge ', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'bg-light badge',
				'options' => [
					'' => esc_html__('Default', 'elementor-genz'),
					'lbl-success'  => esc_html__('Color Primary', 'elementor-genz'),
					'lbl-danger' => esc_html__('Color Danger', 'elementor-genz'),
					'bg-info' => esc_html__('Color Info', 'elementor-genz'),
					'bg-success' => esc_html__('Color Success', 'elementor-genz'),
				],
			]
		);
		$repeater->add_control(
			'plan_badge_name',
			[
				'label' => esc_html__('Plan Badge Name', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);
		$repeater->add_control(
			'sub_title',
			[
				'label' => esc_html__('Package Sub Title', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' =>  esc_html__("Best for personal use", 'elementor-genz'),
			]
		);
		$repeater->add_control(
			'description',
			[
				'label' => esc_html__('Sub-title', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__('Get started without creadit card or payment method', 'elementor-genz'),
			]
		);
		$repeater->add_control(
			'try_btn',
			[
				'label' => esc_html__('Try For Free Button Text', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('Try For Free', 'elementor-genz'),
				'label_block' => true
			]
		);
		$repeater->add_control(
			'try_btn_link',
			[
				'label' => esc_html__('Button Link', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('#', 'elementor-genz'),
				'label_block' => true
			]
		);
		$repeater->add_control(
			'learn_more_btn',
			[
				'label' => esc_html__('Learn More Text', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('Try For Free', 'elementor-genz'),
				'label_block' => true
			]
		);
		$repeater->add_control(
			'learn_more_link',
			[
				'label' => esc_html__('Learn More Link', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('#', 'elementor-genz'),
				'label_block' => true
			]
		);

		$features = new \Elementor\Repeater();
		$features->add_control(
			'feature_item',
			[
				'label' => esc_html__('Features', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true
			]
		);
		$repeater->add_control(
			'features',
			[
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $features->get_controls(),
				'title_field' => '{{{ feature_item }}}',
				'label_block' => true
			]
		);
		$this->add_control(
			'pricing_tables',
			[
				'label' => esc_html__('Pricing Tables', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '<strong>{{{ package_name }}}</strong>',
				'default' => [
					[
						'package_name'		    => esc_html__('Free', 'elementor-genz'),
						'plan_badge_enable'		=> 'yes',
						'plan_badge_name'		=>  esc_html__('Standard', 'elementor-genz'),
						'sub_title' 			=>  esc_html__('Best for personal use', 'elementor-genz'),
						'description'			=>  esc_html__('Get started without creadit card or payment method', 'elementor-genz'),
						'try_btn' 				=> esc_html__('Try For Free', 'elementor-genz'),
						'try_btn_link' 			=> esc_html__('#', 'elementor-genz'),
						'learn_more_btn' 		=> esc_html__('learn more', 'elementor-genz'),
						'learn_more_link' 		=> esc_html__('#', 'elementor-genz'),
						'features' => [
							[
								'feature_item' => esc_html__('Unlimited Storage', 'elementor-genz'),
							],
							[
								'feature_item' => esc_html__('Unlimited Members', 'elementor-genz'),
							],
							[
								'feature_item' => esc_html__('Two-Factor Authentication', 'elementor-genz'),
							],
							[
								'feature_item' => esc_html__('Collaborative Docs', 'elementor-genz'),
							],
							[
								'feature_item' => esc_html__('Sprint Management', 'elementor-genz'),
							]
						]
					],
					[

						'package_name'		    => esc_html__('Business', 'elementor-genz'),
						'plan_badge_enable'		=> 'yes',
						'plan_badge_name'		=>  esc_html__('Standard', 'elementor-genz'),
						'sub_title' 			=>  esc_html__('Best for personal use', 'elementor-genz'),
						'description'			=>  esc_html__('Get started without creadit card or payment method', 'elementor-genz'),
						'try_btn' 				=> esc_html__('Try For Free', 'elementor-genz'),
						'try_btn_link' 			=> esc_html__('#', 'elementor-genz'),
						'learn_more_btn' 		=> esc_html__('learn more', 'elementor-genz'),
						'learn_more_link' 		=> esc_html__('#', 'elementor-genz'),
						'features' => [
							[
								'feature_item' => esc_html__('Unlimited Storage', 'elementor-genz'),
							],
							[
								'feature_item' => esc_html__('Unlimited Members', 'elementor-genz'),
							],
							[
								'feature_item' => esc_html__('Two-Factor Authentication', 'elementor-genz'),
							],
							[
								'feature_item' => esc_html__('Collaborative Docs', 'elementor-genz'),
							],
							[
								'feature_item' => esc_html__('Sprint Management', 'elementor-genz'),
							]
						]
					],
					[

						'package_name'		    => esc_html__('Enterprise ', 'elementor-genz'),
						'plan_badge_enable'		=> 'yes',
						'plan_badge_name'		=>  esc_html__('Standard', 'elementor-genz'),
						'sub_title' 			=>  esc_html__('Best for personal use', 'elementor-genz'),
						'description'			=>  esc_html__('Get started without creadit card or payment method', 'elementor-genz'),
						'try_btn' 				=> esc_html__('Try For Free', 'elementor-genz'),
						'try_btn_link' 			=> esc_html__('#', 'elementor-genz'),
						'learn_more_btn' 		=> esc_html__('learn more', 'elementor-genz'),
						'learn_more_link' 		=> esc_html__('#', 'elementor-genz'),
						'features' => [
							[
								'feature_item' => esc_html__('Unlimited Storage', 'elementor-genz'),
							],
							[
								'feature_item' => esc_html__('Unlimited Members', 'elementor-genz'),
							],
							[
								'feature_item' => esc_html__('Two-Factor Authentication', 'elementor-genz'),
							],
							[
								'feature_item' => esc_html__('Collaborative Docs', 'elementor-genz'),
							],
							[
								'feature_item' => esc_html__('Sprint Management', 'elementor-genz'),
							]
						]
					]

				]

			]
		);


		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();
		genz_framework_template('elements/genz-pricing-tables', '', $settings);
	}
}
