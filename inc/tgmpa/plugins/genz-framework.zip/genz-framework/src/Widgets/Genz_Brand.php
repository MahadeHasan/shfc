<?php

namespace ControlEvents\Widgets;

class Genz_Brand extends \Elementor\Widget_Base
{
	public function get_name()
	{
		return 'brand';
	}

	public function get_title()
	{
		return esc_html__('Brand Logo', 'elementor-genz');
	}

	public function get_icon()
	{
		return 'eicon-image-rollover';
	}

	public function get_categories()
	{
		return ['elementor-genz'];
	}

	public function get_keywords()
	{
		return ['brand', 'genz'];
	}

	protected function register_controls()
	{
		// Brand Logo Tab Start    
		// Brand Logo Tab Start   
		$this->start_controls_section(
			'brand_tab',
			[
				'label' => esc_html__('Brand Logo', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'brand_image_link',
			[
				'label' => esc_html__('Brand Image Link', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'brand_image',
			[
				'label' => esc_html__('Brand Image', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
			]
		);
		$this->add_control(
			'brands',
			[
				'label' => esc_html__('Brands', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => $this->brand_defaults_image(),
			]
		);
		$this->end_controls_section();


		// About Features Tab Start  
		$this->start_controls_section(
			'learn_more_tab',
			[
				'label' => esc_html__('Learn More ', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'title_text',
			[
				'label' => esc_html__('Title Text', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'default' => 'Content publishing cooperation with my partners',
			]
		);
		$this->add_control(
			'learn_more_text',
			[
				'label' => esc_html__('Button Title', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => 'Learn More',
			]
		);
		$this->add_control(
			'learn_more_link',
			[
				'label' => esc_html__('Link', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '#',
			]
		);

		$this->end_controls_section();
	}

	protected function brand_defaults_image()
	{
		return array(
			[
				'title'				=> 'Agon',
				'brand_image'		=> ['url' => get_theme_file_uri('assets/imgs/page/homepage3/agon.svg')],
			],
			[
				'title'				=> 'Hairier',
				'brand_image'		=> ['url' => get_theme_file_uri('assets/imgs/page/homepage3/mon.svg')],
			],
			[
				'title'				=> 'Fig',
				'brand_image'		=> ['url' => get_theme_file_uri('assets/imgs/page/homepage3/fig.svg')],
			],
			[
				'title'				=> 'Flow',
				'brand_image'		=> ['url' => get_theme_file_uri('assets/imgs/page/homepage3/flow.svg')],
			],
			[
				'title'				=> 'Evara',
				'brand_image'		=> ['url' => get_theme_file_uri('assets/imgs/page/homepage3/evara.svg')],
			]
		);
	}
	protected function render()
	{
		$settings = $this->get_settings_for_display();
		genz_framework_template('elements/genz-brand', '', $settings);
	}
}
