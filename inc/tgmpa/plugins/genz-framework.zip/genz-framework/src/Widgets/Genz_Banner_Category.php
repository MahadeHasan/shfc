<?php

namespace ControlEvents\Widgets;

class Genz_Banner_Category extends \Elementor\Widget_Base
{
	public function get_name()
	{
		return 'genz_banner_category';
	}

	public function get_title()
	{
		return esc_html__('Banner With Categories', 'elementor-genz');
	}

	public function get_icon()
	{
		return 'eicon-post-list';
	}

	public function get_categories()
	{
		return ['elementor-genz'];
	}

	public function get_keywords()
	{
		return ['categories'];
	}

	protected function register_controls()
	{

		// About Features Tab Start  
		$this->start_controls_section(
			'banner_category_tab',
			[
				'label' => esc_html__('Banner With Categories', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label' => esc_html__('Sub Title', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_attr__('Welcome to our blog', 'elementor-genz'),
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__('Title', 'elementor-genz'),
				'description'	=> esc_html__('Use { your text } to mark highlight text', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'default' => esc_attr__('Being Unique is better	than being Effect', 'elementor-genz'),

			]
		);
		$this->add_control(
			'number_of_category',
			[
				'label' => esc_html__('Number of Categories', 'elementor-genz'),
				'description'	=> esc_html__('Enter your number, how many categories you wanna show', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 5,

			]
		);
		$this->add_control(
			'select_category_style',
			[
				'label' => esc_html__('Select Category Style ', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'box',
				'options' => [
					'box' => esc_html__('Default Style', 'elementor-genz'),
					'horizontal'  => esc_html__('Style  Two', 'elementor-genz'),
				],
				'label_block'	=> true,
			]
		);
		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();
		genz_framework_template('elements/genz-banner-category', '', $settings);
	}
}
