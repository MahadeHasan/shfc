<?php

namespace ControlEvents\Widgets;

class About_Us extends \Elementor\Widget_Base
{
	public function get_name()
	{
		return 'about_us';
	}

	public function get_title()
	{
		return esc_html__('About Us', 'elementor-genz');
	}

	public function get_icon()
	{
		return 'eicon-image-before-after';
	}

	public function get_categories()
	{
		return ['elementor-genz'];
	}

	public function get_keywords()
	{
		return ['about', 'event'];
	}

	protected function register_controls()
	{

		// About Features Tab Start  
		$this->start_controls_section(
			'about_tab',
			[
				'label' => esc_html__('About Content', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'about_sub_title',
			[
				'label' => esc_html__('Title', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__('Hello Everyone!', 'elementor-genz'),
			]
		);
		$this->add_control(
			'about_title',
			[
				'label' => esc_html__('Title', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__('I’m', 'elementor-genz'),
				'label_block' => true,
			]
		);
		$this->add_control(
			'about_typewrite',
			[
				'label' => esc_html__('Typewrite Text', 'elementor-genz'),
				'description' => esc_html__('If you want to write multiple text then use , ', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__('Brian Clark', 'elementor-genz'),
				'label_block' => true,
			]
		);
		$this->add_control(
			'about_description',
			[
				'label' => esc_html__('About Description', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__('I use animation as a third dimension by which to simplify experiences and kuiding thro each and every interaction. I’m not adding motion just to spruce things up, but doing it in ways that.', 'elementor-genz'),
				'label_block' => true,
			]
		);
		$this->add_control(
			'show_subscription_form',
			[
				'label' => esc_html__('Show Subscription form', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'return_value' => 'yes'
			]
		);
		$this->add_control(
			'email_placeholder',
			[
				'label' => esc_html__('Email placeholder', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__('Type your email address', 'elementor-genz'),
				'condition' => [
					'show_subscription_form' => 'yes',
				],
			]
		);
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__('Subscription Button text', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__('Subscribe', 'elementor-genz'),
				'condition' => [
					'show_subscription_form' => 'yes',
				],
			]
		);
		$this->add_control(
			'show_custom_button',
			[
				'label' => esc_html__('Show Custom Button', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'no'
			]
		);
		$this->add_control(
			'social_link_switch',
			[
				'label' => esc_html__('Show Social Icon', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'no',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'custom_button_tab',
			[
				'label' => esc_html__('Custom Button', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => [
					'show_custom_button' => 'yes'
				]
			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'custom_button_link',
			[
				'label' => esc_html__('Custom Button Link', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'custom_button_text',
			[
				'label' => esc_html__('Custom Button Text', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'custom_button_',
			[
				'label' => esc_html__('Custom Button', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'custom_button_text' 	=> esc_html__('Button', 'elementor-genz'),
						'custom_button_link' 	=> esc_url('#')
					],
				],

				'title_field' => '{{{ custom_button_text }}}',
			]
		);

		$this->end_controls_section();
		// Social Link Tab Start
		$this->start_controls_section(
			'social_link_icon',
			[
				'label' => esc_html__('Social Media', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'label_block' => true,
				'condition' => [
					'social_link_switch' => 'yes',
				],
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'social_title',
			[
				'label' => esc_html__('Social Media Title', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'social_link',
			[
				'label' => esc_html__('Social Media Link', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'social_links',
			[
				'label' => esc_html__('Brands', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'social_title' 	=> esc_html__('Facebook', 'elementor-genz'),
						'social_link' 	=> esc_url('https://www.facebook.com/#')
					],
					[
						'social_title' 	=> esc_html__('Instagram', 'elementor-genz'),
						'social_link' 	=> esc_url('https://www.instagram.com/#')
					],
					[
						'social_title' 	=> esc_html__('Snapchat', 'elementor-genz'),
						'social_link' 	=> esc_url('https://www.snapchat.com/#')
					],
					[
						'social_title' 	=> esc_html__('Twitter', 'elementor-genz'),
						'social_link' 	=> esc_url('https://www.twitter.com/#')
					]
				],
				'title_field' => '{{{ social_title }}}',
			]
		);
		$this->end_controls_section();


		// Content Tab Start
		$this->start_controls_section(
			'about_images',
			[
				'label' => esc_html__('About Image', 'elementor-genz'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'floting_image1',
			[
				'label' => esc_html__('Choose Image 1', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_theme_file_uri('assets/imgs/page/homepage3/banner-1.jpg'),
				],
				'condition' => [
					'floting_image_switch' => 'yes',
				],
				'label_block' => true,
			]
		);
		$this->add_control(
			'floting_image2',
			[
				'label' => esc_html__('Choose Image 2', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_theme_file_uri('assets/imgs/page/homepage3/banner-2.jpg'),
				],
				'condition' => [
					'floting_image_switch' => 'yes',
				],
				'label_block' => true,
				'label_block' => true,
			]
		);
		$this->add_control(
			'floting_image_switch',
			[
				'label' => esc_html__('Choose Floating Image', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'label_on' => esc_html__('Yes', 'elementor-genz'),
				'label_off' => esc_html__('No', 'elementor-genz'),
				'return_value' => 'yes',
			]
		);
		$this->add_control(
			'about_image',
			[
				'label' => esc_html__('Choose About Image', 'elementor-genz'),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => get_theme_file_uri('assets/imgs/page/homepage1/banner.png'),
				],
				'condition' => [
					'floting_image_switch!' => 'yes',
				],
				'label_block' => true,
			]
		);
		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();

		get_template_part('template-parts/elements/about', '', $settings);
	}
}
